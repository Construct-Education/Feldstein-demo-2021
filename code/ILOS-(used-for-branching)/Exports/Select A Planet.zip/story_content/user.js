function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6GoVeeqoau0":
        Script1();
        break;
      case "6bYrXhCLDPs":
        Script2();
        break;
      case "6DRtVWH2VCs":
        Script3();
        break;
  }
}

function Script1()
{
  window.top.changeButtonURL();
}

function Script2()
{
  parent.changeButtonURL();
}

function Script3()
{
  window.top.changeButtonURL();
}

